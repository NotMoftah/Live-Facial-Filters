# I'm busy with my exams right now, there'll be a proper documentation in the next week:
# For now, Just run the ' Engine' Script in Kernel and it'll fire up.

# GoEngine
2D OpenGL Scripting Game Engine.
  - Simple
  - Quick
  - Efficient

# Features:

  - GameObjects Transformation.
  - Camera Transformation.
  - Collision Detection.
  - Sprite Rendering.
  - lighting.
  - Timing.
  - ...
 

# Notes:
    This game engine is pure OpenGL EXCEPT for the usage of pyGame to load images.
